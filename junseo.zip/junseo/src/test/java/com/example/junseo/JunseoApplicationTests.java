package com.example.junseo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunseoApplicationTests {

	@Test
	void contextLoads() {
	}

}
