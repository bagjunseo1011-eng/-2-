package com.example.junseo.repository;

import com.example.junseo.domain.Member;

public interface MemberRepository {
    void save(Member member);
}
