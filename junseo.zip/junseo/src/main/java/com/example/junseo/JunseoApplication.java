package com.example.junseo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunseoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunseoApplication.class, args);
	}

}
