package com.example.junseo.repository;

import com.example.junseo.domain.Member;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Slf4j
@Repository
public class MemberRepositoryImpl implements MemberRepository {
    // JSON 파일 읽기 쓰기용
    private final ObjectMapper objectMapper = new ObjectMapper();

    // 회원 데이터 저장할 파일 위치
    private static final String DATA_FILE_PATH = "data/members.json";

    // 메모리 저장소
    private final Map<Long, Member> store = new ConcurrentHashMap<>();

    // id 자동 증가 쉬퀀스
    private final AtomicLong sequence = new AtomicLong();

    public MemberRepositoryImpl() {//생성자

        loadDataFromFile();//앱시작시 파일 -> 메모리 로드
    }

    @Override
    public void save(Member member) {
//신규 회원인지 체크
        if (member.getId() == null) {
            long newId = sequence.incrementAndGet();
            member.setId(newId);
            store.put(newId, member);
        } else {
           //이미 id가 있으면 해당아이디로 저장
            store.put(member.getId(), member);
        }

        // 모든 회원정보 파일로 저장
        saveDataToFile();
    }

    private void loadDataFromFile() {
        File file = new File(DATA_FILE_PATH);

        if (file.exists()) {
            try {
                List<Member> members = objectMapper.readValue(file, new TypeReference<List<Member>>() {});
                for (Member member : members) {
                    store.put(member.getId(), member);
                    if (member.getId() > sequence.get()) {
                        sequence.set(member.getId() + 1);
                    }
                }
                log.info("회원데이터 로드: {} 명", members.size());
            } catch (IOException e) {
                throw new RuntimeException("회원 데이터 로드 실패", e);//예외처리
            }
        } else {
            File directory = new File("data");
            if (!directory.exists()) {
                directory.mkdirs();
            }
            log.info("기존 데이터 파일이없어 새로 시작합니다");
        }
    }

    private void saveDataToFile() {
        try {
            List<Member> members = new ArrayList<>(store.values());
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(DATA_FILE_PATH), members);
        } catch (IOException e) {
            log.error("회원데이터 저장 실패", e);
            throw new RuntimeException("데이터 저장 실패", e);
        }
    }
}