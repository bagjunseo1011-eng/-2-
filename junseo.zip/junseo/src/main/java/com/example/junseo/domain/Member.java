package com.example.junseo.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class Member {
    private Long id;
    private String userId; // 로그인
    private String password;
    private String username; // 사용자 이름

    public Member (String userId, String password, String username) {
        this.userId = userId;
        this.password = password;
        this.username = username;
    }
}


