package com.example.junseo.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class MemberDTO {
  // static 내부클래스용
    private MemberDTO() {}

    //요청 dto 모음
    @Data
    @NoArgsConstructor
    public static class Request {

        @Data
        @NoArgsConstructor
        public static class Create {
            private String userId;
            private String password;
            private String username;
        }

        //회원정보 수정용
        @Data
        @NoArgsConstructor//필수!
        public static class Update {
            private String username;
            private String password;
        }

        //로그인 요청용
        @Data
        @NoArgsConstructor//필수
        public static class Login {
            private String userId;
            private String password;
        }
    }

    //응답 dto모음
    public static class Response {
        @Data
        @AllArgsConstructor
        public static class Member {
            private Long id;
            private String userId;
            private String username; // password is not exposed
        }
    }

    //응답 래퍼스
    @Data
    @AllArgsConstructor//필수!
    public static class Result<T> {
        private T data;
    }
}


