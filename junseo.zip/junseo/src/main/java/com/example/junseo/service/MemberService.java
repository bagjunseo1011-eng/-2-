package com.example.junseo.service;

import com.example.junseo.domain.Member;
import com.example.junseo.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;

    //회원가입
    public Long signUp(Member member) {
        //비밀번호를 bcrypt로 저장
        String hashedPassword = BCrypt.hashpw(member.getPassword(), BCrypt.gensalt());
        member.setPassword(hashedPassword);

        memberRepository.save(member);
        return member.getId();
    }
}
