package com.example.junseo.controller;

import com.example.junseo.DTO.MemberDTO;
import com.example.junseo.domain.Member;
import com.example.junseo.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api")
public class MemberController {
    private final MemberService memberService;

    //회원가입 api
    //http 메서드 post

    @PostMapping("/members")
    public MemberDTO.Result<Long> saveMember(@RequestBody MemberDTO.Request.Create request) {
        // dto에서 도메인 객체로 변환
        Member member = new Member();
        member.setUserId(request.getUserId());
        member.setPassword(request.getPassword());
        member.setUsername(request.getUsername());

        // 서비스 계층 호출하여 회원가입 처리
        Long id = memberService.signUp(member);

        // 결과 반환
        return new MemberDTO.Result<>(id);
    }
}
